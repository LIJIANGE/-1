import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//�жϲ����Ϸ��ԣ�����Ϸ������ɶ�Ӧ�����ļ���ʽ�����Ϸ�������ֹ
		//�ж��Ƿ�Ϊ����
		int n=0;
		try{
			n=Integer.parseInt(args[0]);
			//�ж����ַ�Χ
			if(n>1000||n<0){
				System.out.println("��������������1-1000��������!");
				return;
			}
			int n1=0;
			int n2=0;
			if(n>=4){
				n1=(int)(n*0.75);
				n2=n-n1;
			}
			else if(n==1){
				n1=n;
				n2=0;
			}
			else{
				n2=1;
				n1=n-n2;
			}
			
			ArrayList<String> ex3=new ArrayList<String>();
			for(int i=0;i<n2;i++){
				String s = Fraction();
				if(s=="error"){
					i--;
					continue;
				}
				ex3.add(s);
			}
			
			ArrayList<String> ex1=new ArrayList<String>();//������ʾ��ʹ�á�
			ArrayList<String> ex2=new ArrayList<String>();//���ڼ��㣬ʹ��/
			//������������ʽ
			for(int i=0;i<n1;i++){
				String[] ex=newE();
				ex1.add(ex[0]);
				ex2.add(ex[1]);
			}//��������ʽ����
			write("../result.txt",calculate(ex2,ex1),ex3);
		}
		catch(Exception e){
			System.out.println("��������������1-1000��������!");
			e.printStackTrace();
			return;
		}
		
	}
	
	//������С��
	private static int divideExactly(int a,int b){
		if(a%b!=0){
			for(int i=a-1;i>0;i--){
				if(a%i==0){
					return i;
				}
			}
			return 1;
		}
		else{
			return b;
		}
	}
	
	//����һ����������ʽ
	private static String[] newE(){
		char[] op=new char[]{'+','-','*','��'};
		char[] brackets=new char[]{'(',')'};
		int flag=0;//�����Ÿ���
		boolean have=false;//�Ƿ�������
		Random rd = new Random();
		//����������ĸ���,3-5��
		int on=rd.nextInt(3)+3;
		//�������������һ�����������
		int[] nums = new int[on+1];
		for(int j=0;j<=on;j++){
			nums[j]=rd.nextInt(101);
		}
		//�������ŵ�λ��
		int[][] position=new int[1][2];
		if(rd.nextInt(10)<3){
			have=true;
			switch(on){
			case 3:
				position=new int[1][2];
				position[0][0]=rd.nextInt(3)+1;
				if(position[0][0]==3){
					position[0][1]=100;
				}else{
					if(rd.nextInt(10)<5){
						position[0][1]=position[0][0]+1;
					}else{
						position[0][1]=position[0][0]+2;
					}
				}break;
			case 4:
				if(rd.nextInt(10)<4){
					position=new int[1][2];
					position[0][0]=rd.nextInt(4)+1;
					if(position[0][0]==4){
						position[0][1]=100;
					}else{
						if(rd.nextInt(10)<5){
							position[0][1]=position[0][0]+1;
						}else{
							position[0][1]=position[0][0]+2;
						}
					}
				}
				else{
					position=new int[2][2];
					position[0][0]=rd.nextInt(4)+1;
					position[1][0]=rd.nextInt(4)+1;
					while(position[0][0]==position[1][0]){
						position[1][0]=rd.nextInt(4)+1;
					}
					for(int i=0;i<2;i++){
						if(position[i][0]==4){
							position[i][1]=100;
						}else{
							if(rd.nextInt(10)<5){
								position[i][1]=position[i][0]+1;
							}else{
								position[i][1]=position[i][0]+2;
							}
						}
					}
				}
				break;
			case 5:
					position=new int[2][2];
					position[0][0]=rd.nextInt(5)+1;
					position[1][0]=rd.nextInt(5)+1;
					while(position[0][0]==position[1][0]){
						position[1][0]=rd.nextInt(5)+1;
					}
					for(int i=0;i<2;i++){
						if(position[i][0]==5||position[i][0]==4){
							position[i][1]=100;
						}else{
							if(rd.nextInt(10)<4){
								position[i][1]=position[i][0]+1;
							}else if(rd.nextInt(10)>6){
								position[i][1]=position[i][0]+2;
							}else{
								position[i][1]=position[i][0]+3;
							}
						}
					}
					break;
			}
		}//����λ�ò������
		
		//��ϳ�Ϊ��������ʽ
		String ex_1=new String();
		String ex_2=new String();
		int[] os=new int[2];
		for(int j=0;j<on;j++){
			if(have)
				os[j%2]=rd.nextInt(3);
			else
				os[j%2]=rd.nextInt(4);
			int o;
			if(j==0){//���ѡ��һ�������
				o=os[0];
			}
			else{
				while(os[j%2]==os[(j+1)%2]){
					if(have)
						os[j%2]=rd.nextInt(3);
					else
						os[j%2]=rd.nextInt(4);
				}
				o=os[j%2];
			}

			if(have){//��������
				if(position.length==1){
					if(position[0][0]==(j+1)){
						ex_1+=String.valueOf(brackets[0])+nums[j];
						ex_2+=String.valueOf(brackets[0])+nums[j];
						flag++;
					}else if(position[0][1]==(j+1)){
						ex_1+=nums[j]+String.valueOf(brackets[1]);
						ex_2+=nums[j]+String.valueOf(brackets[1]);
						flag--;
					}
					else{
						ex_1+=nums[j];
						ex_2+=nums[j];
					}
				}else{
					boolean yes=true;//�Ƿ����ӹ�һ�Σ�trueΪû���ӹ�����
					for(int k=0;k<2;k++){
						if(position[k][0]==(j+1)){
							if(yes){
								ex_1+=String.valueOf(brackets[0])+nums[j];
								ex_2+=String.valueOf(brackets[0])+nums[j];
							}else{
								ex_1+="+"+String.valueOf(brackets[0])+rd.nextInt(10);
								ex_2+="+"+String.valueOf(brackets[0])+rd.nextInt(10);
							}
							flag++;
							yes=false;
						}else if(position[k][1]==(j+1)){
							if(yes){
								ex_1+=nums[j]+String.valueOf(brackets[1]);
								ex_2+=nums[j]+String.valueOf(brackets[1]);
							}else{
								ex_1+="+"+rd.nextInt(10)+String.valueOf(brackets[1]);
								ex_2+="+"+rd.nextInt(10)+String.valueOf(brackets[1]);
							}
							flag--;
							yes=false;
						}
					}
					if(yes){//û���ӹ�����
						ex_1+=nums[j];
						ex_2+=nums[j];
					}
				}
			}
			else{
				ex_1+=nums[j];
				ex_2+=nums[j];
			}//�������Ž���
			ex_1+=String.valueOf(op[o]);//�粻ʹ��String.valueOf���޷����ӷ���
			if(o==3){//����С���ͱ�����Ϊ0�����
				while(nums[j+1]==0){
					nums[j+1]=rd.nextInt(101);
				}
				nums[j+1]=divideExactly(nums[j],nums[j+1]);
				ex_2+="/";
				continue;
			}
			if(o==1){//��������
				if(nums[j+1]>nums[j]){
					if(nums[j]==0)
						nums[j]++;
					nums[j+1]=rd.nextInt(nums[j]);
				}
			}
			ex_2+=String.valueOf(op[o]);
		}
		ex_1+=nums[on];
		ex_2+=nums[on];
		while(flag>0){
			ex_1+=String.valueOf(brackets[1]);
			ex_2+=String.valueOf(brackets[1]);
			flag--;
		}
		String[] str = new String[2];
		str[0]=ex_1;
		str[1]=ex_2;
		return str;
	}
	
	//������������ʽ
	private static ArrayList<String> calculate(ArrayList<String> al,ArrayList<String> al2){
		ArrayList<String> ans = new ArrayList<String>();
		//al�����ã�al2�����
		for(int i=0;i<al.size();i++){
//			try {
				String s=al.get(i);
//				String x=se.eval(s).toString();
//				int x2=(int)Double.parseDouble(x);
				InToPost ip = new InToPost(s,100,1);
				ip.doTrans();
				int answer = ip.calculate();
				if(answer==(-100000)){
					String[] change=newE();
					al2.set(i, change[0]);
					al.set(i, change[1]);
					i--;
					continue;
				}
				s=al2.get(i)+"="+answer;
				ans.add(s);
//			} catch (ScriptException e) {
				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
		}
		return ans;
	}
	
	//�����д���ļ�
	private static void write(String p,ArrayList<String> a,ArrayList<String> b){
		try {
			FileWriter fw = new FileWriter(p);
			BufferedWriter bw = new BufferedWriter(fw);
			fw.write("2016012037");
			bw.newLine();
			ArrayList<String> whole = new ArrayList<String>();
			int al=a.size();
			int bl=b.size();
			while((al>0)|(bl>0)){
				if(al>0){
					whole.add(a.get(al-1));
					al--;
				}
				if(bl>0){
					whole.add(b.get(bl-1));
					bl--;
				}
			}
			for(String s:whole){
				bw.write(s);
				bw.newLine();
			}
			bw.close();
			fw.close();
			System.out.println("��Ŀд����ϣ�");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static String Fraction(){
		Random rd = new Random();
		//����������ĸ���,3-5��
		int on=rd.nextInt(2)+3;
		//�������������һ�����������
		int[][] nums = new int[on+1][2];
		for(int i=0;i<=on;i++){
			nums[i][0]=rd.nextInt(5);
			while(nums[i][0]==0){
				nums[i][0]=rd.nextInt(20);
			}
			nums[i][1]=rd.nextInt(20-nums[i][0])+nums[i][0]+20;
			int k=nums[i][0];
			while(k>1){//����
				if((nums[i][1]%k==0)&&(nums[i][0]%k==0)){
					nums[i][1]/=k;
					nums[i][0]/=k;
					if(nums[i][0]<k){
						k=nums[i][0];
						continue;
					}
				}
				k--;
			}
		}
		//��������ʽ���������
		String result="";
		for(int i=0;i<on;i++){
			int o;
			if(rd.nextInt(10)<3)
				o=0;
			else
				o=1;
			
			if(nums[i][1]==nums[i+1][1]){
				if(nums[i][0]<nums[i+1][0]){
					o=0;
				}
				if(nums[i][0]>nums[i][1]){
					o=1;
				}
				if(i==0){//����
					if(o==0){
						result+=nums[0][0]+"/"+nums[0][1]+"+"+nums[1][0]+"/"+nums[1][1];
					}else{
						result+=nums[0][0]+"/"+nums[0][1]+"-"+nums[1][0]+"/"+nums[1][1];
					}
				}else{
					if(o==0){
						result+="+"+nums[i+1][0]+"/"+nums[i+1][1];
					}
					else{
						result+="-"+nums[i+1][0]+"/"+nums[i+1][1];
					}
				}//�������
				if(o==0){
					nums[i+1][0]+=nums[i][0]+nums[i+1][0];
				}
				else{
					nums[i+1][0]+=nums[i][0]-nums[i+1][0];
				}
			}
			else{
				int[][] temp=new int[2][2];
				temp[1][0]=nums[i][1]*nums[i+1][0];
				temp[0][0]=nums[i][0]*nums[i+1][1];
				temp[0][1]=nums[i][1]*nums[i+1][1];
				temp[1][1]=nums[i][1]*nums[i+1][1];
				if(temp[0][0]<temp[1][0]){
					o=0;
				}
				if(temp[0][0]>temp[0][1]){
					o=1;
				}
				if(i==0){//����
					if(o==0){
						result+=nums[0][0]+"/"+nums[0][1]+"+"+nums[1][0]+"/"+nums[1][1];
					}else{
						result+=nums[0][0]+"/"+nums[0][1]+"-"+nums[1][0]+"/"+nums[1][1];
					}
				}else{
					if(o==0){
						result+="+"+nums[i+1][0]+"/"+nums[i+1][1];
					}
					else{
						result+="-"+nums[i+1][0]+"/"+nums[i+1][1];
					}
				}//�������
				int t;
				if(o==0){//�ӷ�
					t=temp[0][0]+temp[1][0];
				}
				else{//����
					t=temp[0][0]-temp[1][0];
				}
				int k=t;
				while(k>1){//����
					if((temp[0][1]%k==0)&&(t%k==0)){
						temp[0][1]/=k;
						t/=k;
						if(t<k){
							k=t;
							continue;
						}
					}
					k--;
				}
				nums[i+1][0]=t;
				nums[i+1][1]=temp[0][1];
			}//�������
		}
		result+="="+nums[on][0]+"/"+nums[on][1];
		if(nums[on][0]>nums[on][1]){
			return "error";
		}
		else{
			return result;
		}
	}
}