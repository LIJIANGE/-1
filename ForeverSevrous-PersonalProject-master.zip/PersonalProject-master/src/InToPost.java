import java.util.LinkedList;

public class InToPost {
   private Stack theStack;
   private String input;
   private String output = "";
   private int up;
   private int low;
   private LinkedList<String> list = new LinkedList<String>();
   
   public InToPost(String in,int up,int low) {//��������������ֿ����½�һ��ջ
      input = in;
      int stackSize = input.length();
      theStack = new Stack(stackSize);
      this.up=up;
      this.low=low;
    	for(int i=0;i<input.length();i++){
    		String temp="";
    		boolean isNum=false;
    		boolean end = false;
    		while(!isOperator(String.valueOf(input.charAt(i)))){
    			temp+=String.valueOf(input.charAt(i));
    			i++;
    			isNum=true;
    			if(i>=input.length()){
    				list.add(temp);
    				end=true;
    				break;
    			}
    		}
    		if(isNum){
    			if(end){
    				break;
    			}
    			i--;
    			list.add(temp);
    		}else{
    			list.add(String.valueOf(input.charAt(i)));
    		}
    	} 	
   }
   public String doTrans() {
      for (int j = 0; j < list.size(); j++) {
    	  char ch = ' ';
         if(list.get(j).length()>1){
        	 ch = '%';
         }else{
        	 ch = list.get(j).charAt(0);
         }
         switch (ch) {
            case '+': 
            case '-':
            gotOper(ch, 1); 
            break; 
            case '*': 
            case '/':
            gotOper(ch, 2); 
            break; 
            case '(': 
            theStack.push(ch);
            break;
            case ')': 
            gotParen(ch); 
            break;
            default: 
            if(j==0){
            	output = output + list.get(j); //����ֱ����������
            }else{
            	output = output +'#'+ list.get(j); //����ֱ����������
            }
            break;
         }
      }
      while (!theStack.isEmpty()) {
         output = output + '#'+theStack.pop();
      }
      return output; 
   }
   
   public void gotOper(char opThis, int prec1) {
      while (!theStack.isEmpty()) {
         char opTop = theStack.pop();
         if (opTop == '(') {
            theStack.push(opTop);
            break;
         }
         else {
            int prec2;
            if (opTop == '+' || opTop == '-')
            prec2 = 1;
            else
            prec2 = 2;
            if (prec2 < prec1) { 
               theStack.push(opTop);
               break;
            }
            else
            output = output + '#'+opTop;
         }
      }
      theStack.push(opThis);
   }
   public void gotParen(char ch){ 
      while (!theStack.isEmpty()) {
         char chx = theStack.pop();
         if (chx == '(') 
         break; 
         else
         output = output + '#'+chx; 
      }
   }
   
   //������������ʽ
   public int calculate(){
	  int answer=0;
      LinkedList<String> mList=new LinkedList<String>();
      String[] postStr=output.split("#");
      for (String s:postStr) {
          if (isOperator(s)){
              if (!mList.isEmpty()){
                  int num1=Integer.valueOf(mList.pop());
                  int num2=Integer.valueOf(mList.pop());
                  int newNum=cal(num2,num1,s);
                  if(newNum>up||newNum<low){
                	  return -100000;
                  }
                  mList.push(String.valueOf(newNum));
              }
          }
          else {
              //������ѹ��ջ��
              mList.push(s);
          }
      }
      if (!mList.isEmpty()){
    	  answer=Integer.parseInt(mList.pop());
      }
      return answer;
   }
   
 //�ж��Ƿ������
   private static boolean isOperator(String oper){
       if (oper.equals("+")||oper.equals("-")||oper.equals("/")||oper.equals("*")
               ||oper.equals("(")||oper.equals(")")) {
           return true;
       }
       return false;
   }
   
   private static int cal(int num1,int num2,String operator){
   	char op = operator.charAt(0);
       switch (op){
           case '+':return num1+num2;
           case '-':return num1-num2;
           case '*':return num1*num2;
           case '/':return num1/num2;
           default :return 0;
       }
   }
   
   class Stack {
      private int maxSize;
      private char[] stackArray;
      private int top;
      public Stack(int max) {
         maxSize = max;
         stackArray = new char[maxSize];
         top = -1;
      }
      public void push(char j) {
         stackArray[++top] = j;
      }
      public char pop() {
         return stackArray[top--];
      }
      public char peek() {
         return stackArray[top];
      }
      public boolean isEmpty() {
         return (top == -1);
     }
   }
}